# ----------------------------------------------------------
# *******           HW 4: Counting                   *******
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
#   Building core components _____   Composing them in main: ______
#
# Reflection:
#
# What do you think about this bottom-up approach?
# Share your thoughts about its effectivness as you implement and
# fully test the core, before coding the main
# ----------------------------------------------------------

def occurrences(phrase: str, letter: str, start: str) -> int:
    """
    >>> occurrences("the", "x", "y")
    0
    >>> occurrences("the", "x", "t")
    0
    >>> occurrences("the quick brown fox", "o", "x")
    0
    >>> occurrences("the quick brown fox", "o", "b")
    2
    """
    pass  # remove pass as soon as you have one line

def main():
    ## Do not delete these lines!!
    import doctest
    doctest.testmod()

    ## Implement the rest of your function below this line


main() 

