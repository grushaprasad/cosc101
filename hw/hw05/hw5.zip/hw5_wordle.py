# ----------------------------------------------------------
# *******           HW 5: Wordle                    *******
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------

##########################################################
#  Starter Code - DO NOT EDIT, except to add docstrings  #
##########################################################

import doctest
import random


def get_vocab(fname):
    """ADD DESCRIPTION HERE. 

    >>> get_vocab('test_words.txt')
    ['hello', 'tests', 'often', 'state', 'error']
    """ 
    with open(fname, 'r') as f:
        vocab = f.read().split()
    return vocab

def format_char(char:str, guess_type:str) -> str:
    """ADD DESCRIPTION HERE
    
    Parameters:
        char (string) a string with one character. 
        guess_type (string) three possibilities: '2', '1' or '0' (for correct, partially correct, incorrect)

    Returns:
         A string with the appropriate background color: green if correct, yellow if partial and white otherwise. 
    """
    char = char.upper()
    if guess_type == '2': # fully correct
        new_char = '\033[1;30;42m {} \033[0;0m'.format(char)
    elif guess_type == '1': # partially correct
        new_char = '\033[1;30;43m {} \033[0;0m'.format(char)
    else: # incorrect
        new_char = '\033[1;30;47m {} \033[0;0m'.format(char)

    return new_char


def make_lowercase(word:str) -> str:
    """ADD DESCRIPTION HERE

    >>> make_lowercase('Hello')
    'hello'

    >>> make_lowercase('hELLo')
    'hello'

    >>> make_lowercase('123')
    '123'
    """
    return word.lower()

def make_uppercase(word:str) -> str:
    """ADD DESCRIPTION HERE

    >>> make_lowercase('Hello')
    'HELLO'

    >>> make_lowercase('hELLo')
    'HELLO'

    >>> make_lowercase('123')
    '123'
    """
    return word.upper()

##########################################################
#              End of Provided Starter Code              #
##########################################################

def select_word(vocab:list) -> str:
    """ Returns a random word from the vocabulary"""

    pass



def get_guess(vocab:list) -> str: 
    """Prompts user for a valid guess

    Parameters:
        vocab: list of valid five letter words

    Returns: 
        A valid five letter word. 

    """
    pass

def check_guess(guess: str, correct:str) -> str:
    """Checks the guess given an correct

    Input: 
        guess: the guess in lower case
        correct: the correct word

    Returns: 
        A string that is length of the guess made up of 2, 1 and 0, depending on whether the character at the corresponding index is correct, partially correct, or incorrect. 

    >>> check_guess('trees', 'think')
    '20000'

    >>> check_guess('taint', 'think')
    '20221'

    >>> check_guess('games', 'think')
    '00000'
    """
    pass


def format_guess(guess:str, checked:str):
    """Creates a formatted version of the guess

    Parameters:
        guess: the guess in lower case
        checked: a string made up of 2,1, and 0 indicating whether the characters in guess are correct, partially correct, or incorrect


    Returns: 
        A formatted string where each character of the guess has the appropriate background based on checked. 

    """
    pass


def play_game(word:str, vocab:list) -> None:
    """Plays one round of wordle given a correct word

    Parameters:
        word: corrrect word
        vocab: list of valid words

    """
    pass


def main():
    doctest.testmod()

    test_words = 'test_words.txt'
    all_words = 'sgb-words.txt'

    ### Write the rest of your code here


main()
