import doctest

# ----------------------------------------------------------
# *******           HW 6: Orders                    *******
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------

##########################################################
#  Starter Code - DO NOT EDIT, except to add docstrings  #
#########################################################

def print_actions() -> None:
    print(' * pm: Print the menu')
    print(' * po: Print your current order')
    print(' * m:  Modify your order')
    print(' * f:  Finalize your order')
    print()

def print_modifications() -> None:
    print(' * +: Add something')
    print(' * -: Delete something')
    print(' * c: No modification')
    print()

def get_menu(): 
    return ['Pasta', 'Rice bowl', 'Tacos', 'Pizza', 'Soda', 'Iced tea']

def get_prices():
    return [15, 17, 9, 12, 3, 4]


##########################################################
#              End of Provided Starter Code              #
#########################################################


def print_menu(menu:list, prices: list) -> None:
    """ Prints the menu
    Parameters:
        menu: list of items on the menu

    >>> print_menu(['Pizza','Fries'], [10, 5])
    1. Pizza: $10
    2. Fries: $5

    >>> print_menu(['Fries', 'Pizza', 'Cake'], [4,8,5])
    1. Fries: $4
    2. Pizza: $8
    3. Cake: $5

    >>> print_menu([], [])
    Come back later!

    """

    pass

def print_order(menu: list, order: list) -> None:
    """Prints orders

    >>> print_order(['Pizza','Fries'], [1, 3])
    * Pizza x 1
    * Fries x 3

    >>> print_order(['Fries', 'Pizza', 'Cake'], [0, 3, -1])
    * Pizza x 3

    """
    pass


def get_action() -> str:
    """ Prompts user to pick an action and returns the action. 

    Parameters: None
    Returns: 
        One of three actions: 
        pm (to print the menu)
        po (to print the order)
        m (to modify the order)
        f (finalize the order)
    """
    pass

def get_modification() -> str:
    """ Prompts user to pick a modification to order

    Parameters: None
    Returns: 
        One of three options: 
        '+', '-', 'c'
    """
    pass


def get_item(orders:list) -> int:
    """ Gets the index of the item in ordets to be modified

    Parameters:
        orders: the current ordets

    Returns: 
        The index of the item to be modified
    """
    pass

def get_quantity() -> int: 
    """ Gets quantity of the item to be modified
    """
    pass


def modify_order(orders: list, ind: int, quantity: int, action: str) -> None: 
    """Adds or subtracts quantity of item from orders

    Parameters:
        orders: list of current orders
        ind: index of the item to be modified
        quantity: number to add or subtract
        action: + or - (to indicate add or subtract)

    Returns: 
        Nothing, modifies original orders list
    """
    pass

def print_total(order, prices):
    pass

def main():
    menu = get_menu()
    prices = get_prices()

    ## Write your code below
    pass

    

doctest.testmod()
main()

