# ----------------------------------------------------------
# -------   HW 3: Bank Deposits             ---------
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------

def print_blank()->None:
    """Prints blank line

    Parameters: 
        None

    Returns:
        None
    """
    pass ## Delete after implementing

def print_separator():
    """Prints separator between deposits

    Parameters: 
        None

    Returns:
        None
    """
    pass ## Delete after implementing


def get_deposit(num:int) -> float: 
    """Gets deposit from user input

    Parameters: 
        num: the number of the deposit

    Returns:
        the user entered deposit as a float
    """
    pass ## Delete after implementing

def make_deposit(balance: float, deposit: float) -> float: 
    """Makes a deposit and prints new balance

    Parameters: 
        balance: amount in account before deposit
        deposit: amount to be deposited

    Returns:
        the new balance after deposit
    """
    pass ## Delete after implementing

def main():
    # Write the statements for the main function below:
    
    pass ## Delete after implementing

main()