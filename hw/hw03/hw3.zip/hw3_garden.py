# ----------------------------------------------------------
# -------   HW 3: Garden             ---------
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------

import math

def get_center_bed_area(side_len: float) -> float:
    """  
    """
    return math.pi * (side_len/4) ** 2 


def get_volume(area: float, depth:float) -> float:
    """ 
    """
    return area/9 * depth/3



def count_plants(area: float, plant_spacing:float) -> int:
    """ 
    """
    plants = int(area / plant_spacing ** 2)
    return plants


def get_garden_plants(central_area: float, plant_spacing:float) -> None:
    """ 
    """
    circle_plants = count_plants(central_area, plant_spacing)  
    each_semi_plants = count_plants(central_area / 2, plant_spacing) 
    total_plants = circle_plants + each_semi_plants * 4
    
    print("Plants for the circle garden:", circle_plants)
    print("Plants for each semicircle garden:", each_semi_plants)
    print("Total plants for garden:", total_plants)

    
def display_cubic_yards(ground_type: str, area_name:str, amount: float) -> None:
    """ 
    """
    print(ground_type, "for", area_name, "garden:", round(amount,1), "cubic yards")
    

##########################################################
#              End of Provided Starter Code              #
##########################################################

def main():
    # Write the statements for the main function below:
       

main()
