# ----------------------------------------------------------
# -------   HW 3: Banner            ---------
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------
# ----------------------------------------------------------
# ANSWER TO TASK A
#
#
#
#
# ----------------------------------------------------------


# Write your code here