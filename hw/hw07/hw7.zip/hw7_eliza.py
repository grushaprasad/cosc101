# ----------------------------------------------------------
# --------              HW 6                       ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
#
# ----------------------------------------------------------

# Implement the functions below in order, 
#   + uncommenting one at a time
#   -> use the menu `Edit > Toggle comment, or the shortcut
#
# Doing so you have only its tests to debug and clear before
# running the tests of the next function

import doctest

def uncapitalize(s: str) -> str:
    """
    Turns the first letter of the string sentence s
    into lower case.
    
    >>> uncapitalize('Sometimes I like the rain')
    'sometimes I like the rain'
    >>> uncapitalize('sometimes I like the rain')
    'sometimes I like the rain'
    >>> uncapitalize('I like the rain')
    'i like the rain'
    >>> uncapitalize('')
    ''
    """
    
    pass

# def replace_pronouns(s: str) -> str:
#     """
#     Changes pronouns in the string sentence s
#     from first person to second person
#     
#     >>> replace_pronouns('I defended my thesis today!!')
#     'you defended your thesis today!!'
#     >>> replace_pronouns('i defended my thesis today!!')
#     'you defended your thesis today!!'
#     >>> replace_pronouns('It is high time I found an alibi')
#     'It is high time you found an alibi'
#     >>> replace_pronouns('I want to meet a mysterious friend')
#     'you want to meet a mysterious friend'
#     >>> replace_pronouns("It's up to me to find time")
#     "It's up to you to find time"
#     """
#     
#     pass
# 
# 
# def remove_fillers(s: str) -> str:
#     """
#     Removes filler words like "well", "because" and "like" from the
#     beginning of sentence s.
#     
#     >>> remove_fillers('Because I do not know what I want')
#     'I do not know what I want'
#     >>> remove_fillers('Well I do not know what I want')
#     'I do not know what I want'
#     >>> remove_fillers('like I do not know what I want')
#     'I do not know what I want'
#     >>> remove_fillers('I do not know what I like because I do not know myself very well')
#     'I do not know what I like because I do not know myself very well'
#     """
#     pass
# 
#  
# def remove_punctuation(s: str) -> str:
#     """
#     Removes punctuation (.,!?) from the end of strings. 
#     >>> remove_punctuation('I love this!!!')
#     'I love this'
# 
#     >>> remove_punctuation('What time is it?')
#     'What time is it'
# 
#     >>> remove_punctuation('This is a sentence')
#     'This is a sentence'
#     
#     >>> remove_punctuation('..!..')
#     ''
#     
#     >>> remove_punctuation('')
#     ''
#     """
#     pass
# 
#     
# def one_word(s: str) -> str:
#     """
#     If the sentence has only one word, return "Can you expand on that?"
#     
#     >>> one_word("Fine")
#     'Can you expand on that?'
#     
#     >>> one_word("Terribe")
#     'Can you expand on that?'
#     
#     >>> one_word("So so")
#     ''
#     
#     >>> one_word(" ")
#     ''
#     """
#     pass
# 
# 
# def sad(s):
#     """
# 
#     If the sentence is "I am sad" or "I am depressed",
#     return the string
#     "I am sorry to hear that. Why do you think you are sad?" or
#     "I am sorry to hear that. Why do you think you are depressed?"
#     
#     >>> sad('I am sad')
#     'I am sorry to hear that. Why do you think you are sad?'
# 
#     >>> sad('I am depressed')
#     'I am sorry to hear that. Why do you think you are depressed?'
# 
#     >>> sad('People sometimes think I am sad')
#     ''
#     """
#     
#     pass
# 
# 
# def all(s: str)-> str:
#     """
#     If s has the word "all" in it, return "In what way?"    
#     
#     >>> all('All people are alike')
#     'In what way?'
# 
#     >>> all('I hate almost all people')
#     'In what way?'
# 
#     >>> all('I think I passed if I recall  correctly')
#     ''
# 
#     >> all('I recall all the movies I watch')
#     'In what way?'
#     
#     >> all('All my friends are from all over the world')
#     'In what way?'
#     
#     >> all('All')
#     ''
#     
#     >> all('I love this')
#     ''
#     """
#     pass
#    
# 
# def always(s: str)->str:
#     """
#     >>> always('I am always late')
#     'Can you think of a specific example?'
# 
#     >>> always('Always people disappoint me')
#     'Can you think of a specific example?'
# 
#     >>> always('People disappoint me always')
#     'Can you think of a specific example?'
# 
#     >>> always('I think I passed if I recall correctly')
#     ''
#     """
#     pass
# 
# def hate(s:str)->str:
#     """
#     If the pattern "hate X" or "dislike X" occurs in s,
#     return the string "Why do you hate X?" or "Why do you dislike X?"
#     (where X can be replaced by any string)
# 
#     >>> hate('I dislike almost all people')
#     'Why do you dislike almost all people?'
# 
#     >>> hate('Sometimes I really hate my sister!')
#     'Why do you hate your sister?'
# 
#     >>> hate('All people are alike')
#     ''
# 
#     """
#     pass
# 
# 
# 
# def am(s:str)->str:
#     """
#     If the phrase "am X" occurs in s,
#     return "Can you reflect on why you are X".
#     
#     If the phrase "was X" occurs in s
#     return "Can you reflect on why you were X".
# 
#     >>> am('I am disappointed')
#     'Can you reflect on why you are disappointed?'
# 
#     >>> am('I was disappointed.')
#     'Can you reflect on why you were disappointed?'
# 
#     >>> am('I would love to go on a tram')
#     ''
#     """
#     
#     pass
# 
# 
# 
# def generic(s:str)->str:
#     """
#     Returns "Is it important to you that X" where X is the input sentence.
# 
#     >>> generic('I forgot my keys again.')
#     'Is it important to you that you forgot your keys again?'
# 
#     >>> generic('I always forget my keys!?')
#     'Is it important to you that you always forget your keys?'
# 
#     >>> generic('I defended my thesis today!!')
#     'Is it important to you that you defended your thesis today?'
#     
#     >>> generic('Well I defended my thesis today!!')
#     'Is it important to you that you defended your thesis today?'
#    
#     """
# 
#     pass
#  
# 
# def generate_response(s):
#     """
#     This function combines all other functions and returns a final response. 
# 
#     >>> generate_response('I am sad')
#     'I am sorry to hear that. Why do you think you are sad?'
# 
#     >>> generate_response('I am always so disappointed in myself')
#     'Can you think of a specific example?'
# 
#     >>> generate_response('Like I was disappointed because I did not get perfect scores')
#     'Can you reflect on why you were disappointed because you did not get perfect scores?'
# 
#     >>> generate_response('I want to be perfect all the time')
#     'In what way?'
# 
#     >>> generate_response('Well I do not want to make any mistakes..')
#     'Is it important to you that you do not want to make any mistakes?'
# 
#     >>> generate_response('Yes')
#     'Can you expand on that?'
# 
#     >>> generate_response('I hate the idea of showing people my weak side')
#     'Why do you hate the idea of showing people your weak side?'
#     
#     """
#     
#     pass
#     

def main():
    doctest.testmod()

main()