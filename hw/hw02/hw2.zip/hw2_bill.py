# ----------------------------------------------------------
# --------               HW 2: Bill                ---------
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------


##########################################################
#  Starter Code - DO NOT EDIT, except to add docstrings  #
##########################################################



def blank():
    """
    Prints a blank line
    """
    print()

def get_total(which: str) -> float:
    """
    Prompts user for total bill before or after tax
    """
    total = float(input("How much is the total bill "+which+" tax? "))
    return total

def compute_tax_rate(before_tax: float, after_tax: float) -> float:
    """
    Computes the rate of tax applied to the bill
    Tax rate is the tax amount divided by the amount before tax. 

    Prints tax rate and then returns it
    """
    tax = after_tax - before_tax
    tax_rate = tax / before_tax
    print("Tax rate: " + str(round(tax_rate * 100, 1)) + "%")
    return tax_rate

##########################################################
#              End of Provided Starter Code              #
##########################################################


def get_gratuity() -> int:
    """
    Prompts use for percentage gratuity from user.
    Returns the gratuity
    """
    pass ## delete this after you implement your function 


def you(tax_rate: float, gratuity: float) -> None:
    """
    Prompts user for cost of their dish.

    Amount owed =  cost + cost * (tax_rate + gratuity) 

    Prints the amount owed
    """
    pass ## delete this after you implement your function 


def main():
    # Write the statements for the main function below:

# Last line of the program: call to execute main defined above
main()