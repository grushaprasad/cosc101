# ----------------------------------------------------------
# --------               HW 2: Age                ---------
# ----------------------------------------------------------
# Recall that homework assignments must be done individually
# When in doubt about the policies, read the syllabus or
# consult with your instructor
# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# ----------------------------------------------------------

def print_greeting(name: str) -> None:
    """
    Prints the greeting
    """
    pass ## delete this after you implement your function 

def print_age(age: float, planet: str) -> None:
    """
    Prints the age on another planet
    """
    pass ## delete this after you implement your function 

def main():
    # Write the statements for the main function below:


# Last line of the program: call to execute main defined above
main()
